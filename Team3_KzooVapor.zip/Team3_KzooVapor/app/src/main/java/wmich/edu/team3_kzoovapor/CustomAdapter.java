package wmich.edu.team3_kzoovapor;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CustomAdapter extends BaseAdapter{
    String [] result;
    Context context;
    int [] imageId;
    private static LayoutInflater inflater=null;
    public CustomAdapter(MainActivity mainActivity, String[] prgmNameList, int[] prgmImages) {
        // TODO Auto-generated constructor stub
        result=prgmNameList;
        context=mainActivity;
        //imageId=prgmImages;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return result.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView tv;
        //ImageView img;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.program_list, null);
        holder.tv=(TextView) rowView.findViewById(R.id.textView1);
        //holder.img=(ImageView) rowView.findViewById(R.id.imageView1);
        holder.tv.setText(result[position]);
        //holder.img.setImageResource(imageId[position]);
        rowView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                switch(position){

		/* The case, break statements allows the switch to scan through one by one and see if a match
		 *  is found. */

                    //first case for the Sports cars for sale website selection start at 0.
                    case 0:
                        Intent intent = new Intent(context, JuiceListActivity.class);
                        context.startActivity(intent);
                        break;
                    //Second case for the Sports car reviews website selection
                    case 1:
                        Intent intent1 = new Intent(context, PromotionsActivity.class);
                        context.startActivity(intent1);
                        break;
                    //third case for the coolest sports car '15 image selection
                    case 2:
                        Intent intent2 = new Intent(context, AdvancedUsersActivity.class);
                        context.startActivity(intent2);
                        break;
                    //fourth case for the Sports car sounds mediaplayer selection
                    case 3:
                        Intent intent3 = new Intent(context, MoneySaverActivity.class);
                        context.startActivity(intent3);
                        break;
                    //the last case for the classic sports car gridview selection
                    case 4:
                        Intent intent4 = new Intent(context, InformationActivity.class);
                        context.startActivity(intent4);
                        break;
                }
            }
        });
        return rowView;
    }

}
